// Auth route handler here
