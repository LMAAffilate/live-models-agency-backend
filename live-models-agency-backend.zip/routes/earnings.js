// Earnings route handler here
